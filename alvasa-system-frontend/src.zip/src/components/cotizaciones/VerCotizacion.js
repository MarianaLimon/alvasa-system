import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Card, Spinner, Button, Row, Col, Accordion } from 'react-bootstrap';
import { BsArrowLeft, BsPencil } from 'react-icons/bs';

const VerCotizacion = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [cotizacion, setCotizacion] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const obtenerCotizacion = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/cotizaciones/${id}`);
        setCotizacion(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error al obtener la cotización:', error);
        setLoading(false);
      }
    };
    obtenerCotizacion();
  }, [id]);

  if (loading) return <div className="text-center mt-4"><Spinner animation="border" /></div>;
  if (!cotizacion) return <div className="text-center mt-4">No se encontró la cotización.</div>;

  const formatCurrency = (value) => !isNaN(value) ? `$${Number(value).toFixed(2)}` : '—';

  return (
    <Card className="m-4 p-4">
      <Card.Body>
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h3 className="mb-0">Cotización {cotizacion.folio}</h3>
          {cotizacion.estatus && (
            <span className={`badge px-4 py-2 fs-6 ${
              cotizacion.estatus === 'Autorizada' ? 'bg-success' :
              cotizacion.estatus === 'En negociación' ? 'bg-warning text-dark' :
              cotizacion.estatus === 'Entregado a cliente' ? 'bg-info text-dark' :
              cotizacion.estatus === 'Declinada' ? 'bg-danger' : ''
            }`}>
              {cotizacion.estatus}
            </span>
          )}
        </div>

        <Row className="mb-4">
          <Col md={6}>
            <Card className="mb-3">
              <Card.Body>
                <Card.Title>Datos Generales</Card.Title>
                <p><strong>Cliente:</strong> {cotizacion.cliente}</p>
                <p><strong>Empresa:</strong> {cotizacion.empresa}</p>
                <p><strong>Fecha:</strong> {cotizacion.fecha}</p>
                <p><strong>Mercancía:</strong> {cotizacion.mercancia}</p>
                <p><strong>Régimen:</strong> {cotizacion.regimen}</p>
                <p><strong>Aduana:</strong> {cotizacion.aduana}</p>
                <p><strong>Tipo de envío:</strong> {cotizacion.tipo_envio}</p>
                <p><strong>Cantidad:</strong> {cotizacion.cantidad}</p>
              </Card.Body>
            </Card>

            <Card className="mb-3">
              <Card.Body>
                <Card.Title>Resumen</Card.Title>
                <p><strong>Propuesta:</strong> {formatCurrency(cotizacion.propuesta)}</p>
                <p><strong>Total:</strong> {formatCurrency(cotizacion.total)}</p>
                <p><strong>Ahorro:</strong> {formatCurrency(cotizacion.ahorro)}</p>
                <p><strong>Notas:</strong> {cotizacion.notas || '—'}</p>
                <p><strong>Fracción / %IGI:</strong> {cotizacion.fraccion_igi || '—'}</p>
                <p><strong>Monto del comisionista:</strong> {formatCurrency(cotizacion.monto_comisionista)}</p>
              </Card.Body>
            </Card>
          </Col>

          <Col md={6}>
            <Accordion defaultActiveKey="0">
              <Accordion.Item eventKey="0">
                <Accordion.Header>Flete Internacional</Accordion.Header>
                <Accordion.Body>
                  <p><strong>Origen-Destino:</strong> {cotizacion.flete_origen_destino || '—'}</p>
                  <p><strong>{cotizacion.flete_concepto_1 || 'Concepto 1'}:</strong> {formatCurrency(cotizacion.flete_valor_1)}</p>
                  <p><strong>{cotizacion.flete_concepto_2 || 'Concepto 2'}:</strong> {formatCurrency(cotizacion.flete_valor_2)}</p>
                  <p><strong>{cotizacion.flete_concepto_3 || 'Concepto 3'}:</strong> {formatCurrency(cotizacion.flete_valor_3)}</p>
                </Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="1">
                <Accordion.Header>Cargos de Traslados</Accordion.Header>
                <Accordion.Body>
                  <p><strong>Próximamente...</strong></p>
                </Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="2">
                <Accordion.Header>Desglose de Impuestos</Accordion.Header>
                <Accordion.Body>
                  <p><strong>Próximamente...</strong></p>
                </Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="3">
                <Accordion.Header>Cargos Extra</Accordion.Header>
                <Accordion.Body>
                  <p><strong>Próximamente...</strong></p>
                </Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="4">
                <Accordion.Header>Servicios</Accordion.Header>
                <Accordion.Body>
                  <p><strong>Próximamente...</strong></p>
                </Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="5">
                <Accordion.Header>Cuenta de Gastos</Accordion.Header>
                <Accordion.Body>
                  <p><strong>Próximamente...</strong></p>
                </Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="6">
                <Accordion.Header>Pedimento</Accordion.Header>
                <Accordion.Body>
                  <p><strong>Próximamente...</strong></p>
                </Accordion.Body>
              </Accordion.Item>
            </Accordion>
          </Col>
        </Row>

        <div className="d-flex justify-content-center gap-3 mt-4">
          <Button variant="secondary" onClick={() => navigate('/cotizaciones')}>
            <BsArrowLeft className="me-2" /> Volver a la lista
          </Button>
          <Button variant="warning" onClick={() => navigate(`/cotizaciones/editar/${id}`)}>
            <BsPencil className="me-2" /> Editar cotización
          </Button>
        </div>
      </Card.Body>
    </Card>
  );
};

export default VerCotizacion;
